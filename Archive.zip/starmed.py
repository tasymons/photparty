#This function takes lists of row and column indices where all star exist and divides them into sublists by star
#It also returns the number of stars by row and by column, and the median pixel values for each star
#By Teresa Symons 2016

def starmed(starrow,starcol):
    #Import math package
    import numpy as np

    #Divide all star location indices by star
    rowloc = []
    colloc = []
    starr = []
    starc = []
    starr.append(starrow[0])
    starc.append(starcol[0])
    #Start adding star indices to a list
    #If difference between previous and next index is greater than 1, assume new star begins and start new list of indices
    for i in range(1,len(starrow)):
        if starrow[i] == starrow[i-1] + 1:
            starr.append(starrow[i])
        elif starrow[i] != starrow[i-1] + 1:
            rowloc.append(starr)
            starr = []
            starr.append(starrow[i])
    rowloc.append(starr)

    for j in range(1,len(starcol)):
        if starcol[j] == starcol[j-1] + 1:
            starc.append(starcol[j])
        elif starcol[j] != starcol[j-1] + 1:
            colloc.append(starc)
            starc = []
            starc.append(starcol[j])
    colloc.append(starc)

    #Calculate number of stars (sublists) found by both row and column
    numstarr = len(rowloc)
    numstarc = len(colloc)

    #Find median pixel value of each star by row and column
    rowmed = []
    colmed = []
    for k in range(0,len(rowloc)):
        rowmed.append(round(np.median(rowloc[k])))
    for k in range(0,len(colloc)):
        colmed.append(round(np.median(colloc[k])))

    return rowloc, colloc, numstarr, numstarc, rowmed, colmed
